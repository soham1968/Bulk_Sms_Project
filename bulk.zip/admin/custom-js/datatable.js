
$(document).ready(function () {
    $('#myTable').DataTable();
});
